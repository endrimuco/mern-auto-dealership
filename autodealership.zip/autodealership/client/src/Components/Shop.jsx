import React from 'react';
import Vehicles from './vehicleComp/Vehicles';
import '../css/Shop.css';
const Shop = () => {
  
  return (

      <div className='shopMainDiv'>     

      <Vehicles />
     
    </div>
  );
};

export default Shop;